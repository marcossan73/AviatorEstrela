# ?? Aviator ML Intelligence (EstrelaBet)

Bem-vindo ao reposit�rio oficial do projeto **Aviator ML Intelligence**!
Este projeto � um sistema automatizado para extra��o, an�lise preditiva e proje��o de tend�ncias do jogo Aviator da casa de apostas "EstrelaBet". O sistema atua de ponta a ponta: captura ass�ncrona dos resultados reais na roleta e processamento instant�neo via Machine Learning para o aux�lio anal�tico dos pr�ximos picos lucrativos.

---

## ?? Como Funciona
O projeto processa continuamente o hist�rico da plataforma atrav�s do Selenium, salva os resultados detectados em arquivos base, treina/sonda os dados acumulados atrav�s de Algoritmos Estat�sticos (Regress�es Polinomiais) e Machine Learning Ensemble (SkLearn, RandomForest e GradientBoosting) para retornar alertas precisos em tela na porta local com Dashboard Flask interativo.

### O sistema � dividido nas duas vers�es e evolu��es distintas:
2. **`aviator_service2.py`** _(Recomendada - Vers�o Stacked Regime Detector)_
    * Uma vers�o evolu�da, com detec��o e classifica��o em tempo real do **Regime (Estado) do Jogo** (Seca Severa, Recupera��o, Est�vel, Distribui��o). 
    * Ajusta a janela de probabilidades na detec��o com bases em *Stacked Ensemble* (GradientBoosting). 
    * **Novidade ML**: Extrai regress�es para prever simultaneamente a **Janela de Tempo (Hor�rio)** em que um pico vai cair, bem como **O Valor do Pico Esperado** (`x20.4`, `x55.2`, etc.).
    * **Hist�rico de Previs�es ("Transpar�ncia ML")**: Armazena permanentemente em disco (via `ml_history.json`) as �ltimas 25 previs�es geradas, exibindo o Timestamp real de _quando_ a I.A gerou a previs�o contraposta � hora em que espera-se o pico. Isso ajuda a medir o n�vel de antecipa��o real do rob�!
    * **Alerta Sonoro Local**: Emite um bipe duplo diretamente no sistema operacional sempre que a janela de previs�o para picos de `>50x` � atualizada, garantindo que o operador seja notificado de mudan�as cr�ticas mesmo sem estar olhando para a tela.
    * **Sa�das Prov�veis e Cruzamento (Polinomial)**: A linha de 'rolling' calcula a curvatura baseada na ponta da montanha russa para tra�ar passos de tend�ncias com cores interativas (`>2 roxo`, `>5 verde`, `>10 rosa`, `>50 azul`) coladas lado-a-lado nas bolhas de hist�rico de rodadas passadas listadas no HTML.

?? Recomenda-se hoje o uso irrestrito do script prim�rio: **`aviator_service2.py`**

---

## ??? Requisitos de Instala��o

Para que o rob� possa interagir com o navegador Chrome de forma oculta (*headless*) e realizar todos esses c�lculos complexos espacial/temporais na sua m�quina, instale as depend�ncias requisitadas. 

Abra seu terminal Python e instale usando nosso arquivo de depend�ncias:

```bash
pip install -r requirements.txt
```

*(O arquivo carrega ferramentas s�lidas como: Pandas, NumPy, Scikit-learn, joblib, Selenium, webdriver-manager e Flask)*

---

## ?? Como Executar

1. Para iniciar completamente o Web-Scraping (capta��o dos lances com atualiza��es a cada 20 segundos) em paridade com o Servidor Local de Interface do Dashboard rodando simultaneamente:

```bash
python aviator_service2.py
```

2. Acesse no seu navegador preferido (PC ou Mobile local): 
   ??? **[http://localhost:5000](http://localhost:5000)**

*(Opcional: Scripts de testes de carregamento do ML dispon�veis como `test_ml.py` ajudam em debugar como os modelos est�o calculando amostras diretamente nas bases JSON/TXT sem precisar da leitura cont�nua Web).*

---

## ?? Funcionalidades do Dashboard Web
O Painel Inteligente auto-gerado traz componentes vitais, como:
- **Painel "Geral"**: Frequ�ncias absolutas das �ltimas 100 rodadas fatiadas por cores estrat�gicas.
- **Painel de Ocorr�ncias e Linha do Tempo Visual**: Gr�fico Chart.JS tra�ado com hist�rico real cruzando com o "fantasma" das curvas de M�dia M�vel (Rolling Mean) e Proje��o (Projection Line).
- **Painel de Picos e Confian�a Artificial**: Detalhamento em janelas precisas do momento exato de cada Spike avaliando se o momento de "Entrar" baseia-se em Confian�a Alta (`> 85%`) ou de Risco (Seca Severa).
- **Sanfona de Tabela Hist�rica**: Dropdowns com mini-tabelas guardando a precis�o preditiva.
- **Sem�foro/Alarmes Sonoros Web**: Ao aceitar no bot�o "Som Ativado", o JavaScript dispara sons vibrantes de aproxima��o temporal (v�rios beeps) avisando quando a janela de entrada est� a menos de `90 segundos` para as velas altas.

---

## ?? Configura��es Customiz�veis
Se preferir ajustar atalhos no topo do script fonte (`aviator_service2.py`):
```python
# Tempo entre varreduras
INTERVALO_SEGUNDOS = 20

# Volume e hist�rico m�ximo carregado no BD de Texto 
MAX_REGISTROS = 10000

# Contas e Autentica��es (Apenas contas tipminer j� logadas):
crie uma conta gratuita no site https://www.tipminer.com e atualize o email e senha nas linhas

37 e 38 do arquivo aviator_service2.py

EMAIL = "seu_email_secreto"
SENHA = "sua_senha_secreta"
```

## ?? M�o na Massa (Como Colaborar)
A colabora��o � altamente encorajada! Sinta-se orgulhoso em criar *Forks*, testar novos algarismos preditivos do SkLearn para o motor do jogo ou melhorar o design HTML.

**Passos b�sicos:**
1. Realize um *Fork* do reposit�rio no seu GitHub.
2. Clone para sua IDE: `git clone https://github.com/marcossan73/AviatorEstrela.git`
3. Crie uma branch para explorar inova��es: `git checkout -b feature/minha-regressao-tunada`
4. Trabalhe e debuge. (Fa�a *commits* sem�nticos como "Feat: Atualizados c�lculos de threshold")
5. Fa�a um *Push* da sua branch e submeta via Pull Request para revis�o central!

> ?? *Nota Comercial*: Use e divirta-se analisando algoritmos temporais, mas lembre-se sempre de apostar responsavelmente dentro das leis em vigor para sua regi�o. As proje��es probabil�sticas deste sistema anal�tico de dados auxiliam nas leituras de longo prazo, **mas nunca devem ser consideradas garantias absolutas e irrevog�veis de lucros.** 

???? Divirta-se!